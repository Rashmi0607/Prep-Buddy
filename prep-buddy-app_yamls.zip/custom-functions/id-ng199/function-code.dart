
  return List.generate(levels, (index) => index + 1);