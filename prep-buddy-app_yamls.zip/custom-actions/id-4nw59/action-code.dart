import 'package:flutter/rendering.dart';

import '/custom_code/actions/init_audio_player.dart';
import 'package:just_audio/just_audio.dart';

Future adjustMusicVolume(double value) async {
  var _audioPlayer = AudioPlayerSingleton().audioPlayer!;

  await _audioPlayer.setVolume(value);
}