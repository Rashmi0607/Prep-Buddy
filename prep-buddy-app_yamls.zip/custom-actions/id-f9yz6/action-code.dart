import 'package:faker/faker.dart';
import 'dart:math';

Future<List<PlayerStruct>> populatePlayers() async {
  // populate List<Player> with 5 items of Player data type and random values for its fields
  List<PlayerStruct> players = [];

  for (int i = 0; i < 10; i++) {
    PlayerStruct player = PlayerStruct(
      isCurrentUser: i == 0 ? true : false,
      profileName: faker.person.name(),
      highScore: Random().nextInt(2000) + 18,
      hasTopRank: Random().nextBool(),
      profileImage:
          "https://mighty.tools/mockmind-api/content/human/${Random().nextInt(20)}.jpg",
    );
    players.add(player);
  }

  return players;
}