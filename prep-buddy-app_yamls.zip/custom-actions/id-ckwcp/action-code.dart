import 'package:faker/faker.dart';
import 'dart:math';

Future<List<LevelStruct>> initializeLevels() async {
  // populate List<Player> with 5 items of Player data type and random values for its fields
  List<LevelStruct> levels = [];

  for (int i = 0; i < 5; i++) {
    LevelStruct level = LevelStruct(
      isLevelLocked: i == 0 ? false : true,
      levelName: "Level ${i}",
      levelDesc: "A great level!",
      completionPerc: i == 0 ? Random().nextDouble() : 0,
      levelNumber: i,
    );
    levels.add(level);
  }

  return levels;
}