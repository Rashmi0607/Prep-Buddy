import 'package:just_audio/just_audio.dart';

// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!

Future initAudioPlayer() async {
  AudioPlayerSingleton().init();
}

class AudioPlayerSingleton {
  static final AudioPlayerSingleton _singleton =
      AudioPlayerSingleton._internal();

  factory AudioPlayerSingleton() {
    return _singleton;
  }

  AudioPlayerSingleton._internal();

  AudioPlayer? audioPlayer;

  init() {
    audioPlayer = AudioPlayer();
  }
}